"""
main.py  v2
────────────
Novedades:
  - Pantalla de inicio: ID paciente, edad, grupo de edad auto-detectado,
    selección de nivel de inicio
  - Calibración de cámara guiada (detecta rango de movimiento del paciente)
  - Feed de cámara grande al centro de la pantalla durante el test
  - Zonas de color en las 4 esquinas de la pantalla (no del feed)
  - Tiempos adaptativos por grupo de edad
  - Manejo seguro de mano fuera de frame
"""

import sys, os, random, time, math
import cv2, pygame
import numpy as np

from config import (COLORS, AGE_GROUPS, LEVEL_NAMES, LEVEL_DESCRIPTIONS,
                    LANGUAGE, FULLSCREEN, FONT_WORD_SIZE_FRAC,
                    FONT_LABEL_SIZE_FRAC, BG_COLOR, TIMER_BAR_HEIGHT,
                    CAM_FEED_W_FRAC, CAM_FEED_H_FRAC, DWELL_TIME_MS,
                    DATA_DIR, REPORTS_DIR, get_age_group, get_level_config)
from hand_tracker   import HandTracker
from data_recorder  import DataRecorder
from report_generator import generate_full_report

# ── Constantes globales ───────────────────────────────────────
LANG         = LANGUAGE
COLOR_DICT   = COLORS[LANG]
COLOR_NAMES  = list(COLOR_DICT.keys())
CORNERS      = ["top_left", "top_right", "bottom_left", "bottom_right"]
MAX_LEVELS   = 5

UI = {
    "es": {
        "title":        "STROOP COGNITIVO",
        "subtitle":     "Evaluación Neuropsicológica Adaptativa",
        "patient_id":   "ID Paciente",
        "patient_age":  "Edad",
        "age_group":    "Grupo de edad",
        "start_level":  "Nivel de inicio",
        "btn_start":    "INICIAR SESIÓN",
        "btn_cal":      "CALIBRAR CÁMARA",
        "cal_title":    "CALIBRACIÓN DE CÁMARA",
        "cal_inst":     "Mueve tu mano por toda la pantalla durante 5 segundos",
        "cal_counting": "Capturando movimiento…",
        "cal_done":     "¡Calibración completa!",
        "cal_fail":     "Calibración insuficiente — intenta de nuevo",
        "instructions": "Señala el COLOR de la tinta, no lo que dice la palabra",
        "dwell_hint":   "Mantén el dedo 0.4s sobre la respuesta",
        "level_lbl":    "NIVEL",
        "correct":      "✓ CORRECTO",
        "wrong":        "✗ INCORRECTO",
        "timeout":      "⏱ TIEMPO",
        "next_level":   "ENTER para continuar al siguiente nivel",
        "finished":     "Sesión completada — generando reporte…",
        "score":        "Precisión",
        "patient":      "Paciente",
        "press_q":      "Q = Salir   ESC = Menú",
        "no_hand":      "✋ Muestra tu mano a la cámara",
        "congr_badge":  "CONGRUENTE",
        "incongr_badge":"INCONGRUENTE",
    },
    "en": {
        "title":        "COGNITIVE STROOP",
        "subtitle":     "Adaptive Neuropsychological Assessment",
        "patient_id":   "Patient ID",
        "patient_age":  "Age",
        "age_group":    "Age group",
        "start_level":  "Starting level",
        "btn_start":    "START SESSION",
        "btn_cal":      "CALIBRATE CAMERA",
        "cal_title":    "CAMERA CALIBRATION",
        "cal_inst":     "Move your hand across the full screen for 5 seconds",
        "cal_counting": "Capturing movement…",
        "cal_done":     "Calibration complete!",
        "cal_fail":     "Insufficient movement — try again",
        "instructions": "Point to the INK COLOR, not what the word says",
        "dwell_hint":   "Hold finger 0.4s on answer",
        "level_lbl":    "LEVEL",
        "correct":      "✓ CORRECT",
        "wrong":        "✗ WRONG",
        "timeout":      "⏱ TIME",
        "next_level":   "ENTER to continue",
        "finished":     "Session complete — generating report…",
        "score":        "Accuracy",
        "patient":      "Patient",
        "press_q":      "Q = Quit   ESC = Menu",
        "no_hand":      "✋ Show your hand to the camera",
        "congr_badge":  "CONGRUENT",
        "incongr_badge":"INCONGRUENT",
    },
}
T = UI.get(LANG, UI["es"])


# ── Helpers de render ─────────────────────────────────────────

def draw_rrect(surf, rect, color, radius=14, alpha=255):
    s = pygame.Surface((rect[2], rect[3]), pygame.SRCALPHA)
    pygame.draw.rect(s, (*color, alpha), (0, 0, rect[2], rect[3]),
                     border_radius=radius)
    surf.blit(s, (rect[0], rect[1]))


def lerp_col(c1, c2, t):
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def text_centered(surf, font, text, color, cx, cy, shadow=False):
    if shadow:
        s = font.render(text, True, (0, 0, 0))
        surf.blit(s, s.get_rect(center=(cx+2, cy+2)))
    lbl = font.render(text, True, color)
    surf.blit(lbl, lbl.get_rect(center=(cx, cy)))
    return lbl.get_rect(center=(cx, cy))


# ══════════════════════════════════════════════════════════════
class StroopGame:

    def __init__(self):
        pygame.init()
        pygame.font.init()

        if FULLSCREEN:
            info = pygame.display.Info()
            self.W, self.H = info.current_w, info.current_h
            self.screen = pygame.display.set_mode(
                (self.W, self.H), pygame.FULLSCREEN)
        else:
            self.W, self.H = 1280, 720
            self.screen = pygame.display.set_mode((self.W, self.H))
        pygame.display.set_caption("Stroop Cognitivo v2")

        # Fuentes
        fw = max(30, int(self.H * FONT_WORD_SIZE_FRAC))
        fl = max(16, int(self.H * FONT_LABEL_SIZE_FRAC))
        self.f_word  = pygame.font.SysFont("Arial", fw, bold=True)
        self.f_label = pygame.font.SysFont("Arial", fl, bold=True)
        self.f_small = pygame.font.SysFont("Arial", fl - 2)
        self.f_tiny  = pygame.font.SysFont("Arial", max(13, fl - 6))
        self.f_big   = pygame.font.SysFont("Arial", fw + 10, bold=True)

        # Módulos
        self.tracker = HandTracker()
        self.clock   = pygame.time.Clock()

        # Sesión (se establece en el intake screen)
        self.patient_id  = "PAC001"
        self.patient_age = 30
        self.age_group   = "young_adult"
        self.start_level = 1
        self.recorder    = None   # se crea al iniciar sesión

        # Estado del juego
        self.phase          = "intake"
        self.current_level  = 1
        self.trial_index    = 0
        self.level_stats    = {}

        # Estímulo actual
        self.word           = ""
        self.word_color     = ""
        self.word_color_rgb = (255,255,255)
        self.correct_answer = ""
        self.corner_map     = {}
        self.zone_rects     = {}

        # Feedback
        self.feedback_text  = ""
        self.feedback_color = (255,255,255)
        self.feedback_until = 0
        self.last_rt_ms     = 0

        # Timing del ensayo
        self.trial_start    = 0.0
        self.stimulus_shown = False
        self.decision_onset = None
        self._pause_start   = None

        # Cámara
        self.finger_px   = None
        self.finger_py   = None
        self.cam_surface = None   # surface pygame del feed

        # Partículas
        self.particles = []

        # ── Geometría del feed central ──────────────────────
        self.cam_w = int(self.W * CAM_FEED_W_FRAC)
        self.cam_h = int(self.H * CAM_FEED_H_FRAC)
        self.cam_x = (self.W - self.cam_w) // 2
        self.cam_y = (self.H - self.cam_h) // 2 + 10

        # ── Intake: campos editables ─────────────────────────
        self._intake_fields = {
            "id":    {"value": "PAC001",  "active": False,
                      "label": T["patient_id"]},
            "age":   {"value": "30",      "active": False,
                      "label": T["patient_age"]},
        }
        self._intake_level  = 1   # nivel de inicio seleccionado

        # ── Calibración ──────────────────────────────────────
        self._cal_phase    = "waiting"   # waiting | recording | done | fail
        self._cal_start    = 0.0
        self._cal_duration = 5.0         # segundos de captura

    # ══════════════════════════════════════════════════════════
    #  CÁMARA
    # ══════════════════════════════════════════════════════════

    def _update_camera(self):
        frame, fx, fy = self.tracker.get_frame_and_finger()
        if frame is None:
            self.finger_px = self.finger_py = None
            self.cam_surface = None
            return

        # Redimensionar al área central
        try:
            cam_small = cv2.resize(frame, (self.cam_w, self.cam_h))
            cam_rgb   = cv2.cvtColor(cam_small, cv2.COLOR_BGR2RGB)
            self.cam_surface = pygame.surfarray.make_surface(
                np.transpose(cam_rgb, (1, 0, 2)))
        except Exception:
            self.cam_surface = None

        # Mapear coordenadas normalizadas a pixels de PANTALLA
        if fx is not None and fy is not None:
            self.finger_px = int(fx * self.W)
            self.finger_py = int(fy * self.H)
        else:
            self.finger_px = self.finger_py = None

    # ══════════════════════════════════════════════════════════
    #  INTAKE (pantalla de inicio)
    # ══════════════════════════════════════════════════════════

    def _phase_intake(self):
        self.screen.fill(BG_COLOR)
        W, H = self.W, self.H

        # Título
        text_centered(self.screen, self.f_big, T["title"],
                       (180,180,255), W//2, H//6, shadow=True)
        text_centered(self.screen, self.f_small, T["subtitle"],
                       (120,120,180), W//2, H//6+50)

        # Panel central
        pw, ph = 500, 420
        px, py = W//2 - pw//2, H//2 - ph//2
        draw_rrect(self.screen, (px, py, pw, ph), (20,20,40), radius=20, alpha=220)
        pygame.draw.rect(self.screen, (60,60,100), (px,py,pw,ph),
                         2, border_radius=20)

        field_y = py + 40
        field_w = 320
        field_x = W//2 - field_w//2

        # ── Campo ID ──────────────────────────────────────────
        f_id  = self._intake_fields["id"]
        lbl   = self.f_small.render(f_id["label"], True, (160,160,200))
        self.screen.blit(lbl, (field_x, field_y))
        field_y += 30
        box_col = (80,130,200) if f_id["active"] else (50,50,80)
        draw_rrect(self.screen, (field_x, field_y, field_w, 40), box_col, alpha=200)
        pygame.draw.rect(self.screen, box_col,
                         (field_x, field_y, field_w, 40), 2, border_radius=8)
        val = self.f_label.render(f_id["value"] + ("|" if f_id["active"] else ""),
                                   True, (255,255,255))
        self.screen.blit(val, (field_x+10, field_y+8))
        field_y += 60

        # ── Campo Edad ────────────────────────────────────────
        f_age = self._intake_fields["age"]
        lbl   = self.f_small.render(f_age["label"], True, (160,160,200))
        self.screen.blit(lbl, (field_x, field_y))
        field_y += 30
        box_col = (80,130,200) if f_age["active"] else (50,50,80)
        draw_rrect(self.screen, (field_x, field_y, field_w, 40), box_col, alpha=200)
        pygame.draw.rect(self.screen, box_col,
                         (field_x, field_y, field_w, 40), 2, border_radius=8)
        val = self.f_label.render(f_age["value"] + ("|" if f_age["active"] else ""),
                                   True, (255,255,255))
        self.screen.blit(val, (field_x+10, field_y+8))
        field_y += 55

        # ── Grupo de edad detectado ───────────────────────────
        try:
            age_int = int(self._intake_fields["age"]["value"])
            ag_key  = get_age_group(age_int)
            ag_lbl  = AGE_GROUPS[ag_key]["label"][LANG]
        except Exception:
            ag_lbl = "—"
        grp_t = self.f_tiny.render(
            f"{T['age_group']}: {ag_lbl}", True, (120,200,160))
        self.screen.blit(grp_t, (field_x, field_y))
        field_y += 35

        # ── Selector de nivel de inicio ───────────────────────
        lbl = self.f_small.render(T["start_level"], True, (160,160,200))
        self.screen.blit(lbl, (field_x, field_y))
        field_y += 28
        btn_w = 52
        for lvl in range(1, MAX_LEVELS+1):
            bx = field_x + (lvl-1)*(btn_w+8)
            selected = (lvl == self._intake_level)
            bcol = (80,140,220) if selected else (35,35,60)
            draw_rrect(self.screen, (bx, field_y, btn_w, 38), bcol,
                       radius=10, alpha=230)
            pygame.draw.rect(self.screen, (80,80,140) if not selected else (120,180,255),
                             (bx, field_y, btn_w, 38), 1, border_radius=10)
            text_centered(self.screen, self.f_small, str(lvl),
                           (255,255,255), bx+btn_w//2, field_y+19)
            # Nombre del nivel debajo
            ln = self.f_tiny.render(
                LEVEL_NAMES[LANG][lvl], True, (100,100,140))
            self.screen.blit(ln, (bx + btn_w//2 - ln.get_width()//2, field_y+40))
        field_y += 80

        # ── Botones ───────────────────────────────────────────
        self._intake_btn_cal   = pygame.Rect(field_x, field_y, field_w//2-5, 44)
        self._intake_btn_start = pygame.Rect(field_x+field_w//2+5, field_y,
                                              field_w//2-5, 44)

        draw_rrect(self.screen, self._intake_btn_cal,   (40,80,120), radius=12,alpha=230)
        draw_rrect(self.screen, self._intake_btn_start, (30,120,60), radius=12,alpha=230)
        pygame.draw.rect(self.screen,(80,140,200), self._intake_btn_cal,  1,border_radius=12)
        pygame.draw.rect(self.screen,(60,200,100), self._intake_btn_start,1,border_radius=12)

        text_centered(self.screen, self.f_tiny, T["btn_cal"],
                       (200,230,255),
                       self._intake_btn_cal.centerx, self._intake_btn_cal.centery)
        text_centered(self.screen, self.f_small, T["btn_start"],
                       (200,255,200),
                       self._intake_btn_start.centerx, self._intake_btn_start.centery)

        # Hint calibración
        if self.tracker.calibration.valid:
            cal_hint = self.f_tiny.render("✓ Cámara calibrada", True, (80,220,100))
        else:
            cal_hint = self.f_tiny.render("⚠ Sin calibrar (recomendado)",True,(220,180,60))
        self.screen.blit(cal_hint, cal_hint.get_rect(
            centerx=W//2, top=self._intake_btn_start.bottom+8))

        hint = self.f_tiny.render(T["press_q"], True, (80,80,110))
        self.screen.blit(hint, hint.get_rect(center=(W//2, H-25)))

        # ── Eventos ───────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT: self._quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q: self._quit()
                if event.key == pygame.K_TAB:
                    keys = ["id","age"]
                    active = next((k for k,v in self._intake_fields.items()
                                   if v["active"]), None)
                    for f in self._intake_fields.values(): f["active"] = False
                    if active:
                        nxt = keys[(keys.index(active)+1) % len(keys)]
                        self._intake_fields[nxt]["active"] = True
                    else:
                        self._intake_fields["id"]["active"] = True

                active_f = next((v for v in self._intake_fields.values()
                                  if v["active"]), None)
                if active_f:
                    if event.key == pygame.K_BACKSPACE:
                        active_f["value"] = active_f["value"][:-1]
                    elif event.key == pygame.K_RETURN:
                        active_f["active"] = False
                    elif event.unicode.isprintable() and len(active_f["value"]) < 20:
                        active_f["value"] += event.unicode

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos
                # Campos
                fy0 = py + 40 + 30
                id_box = pygame.Rect(field_x, fy0, field_w, 40)
                fy1 = fy0 + 100
                age_box = pygame.Rect(field_x, fy1, field_w, 40)
                for k,v in self._intake_fields.items(): v["active"] = False
                if id_box.collidepoint(mx,my):
                    self._intake_fields["id"]["active"] = True
                elif age_box.collidepoint(mx,my):
                    self._intake_fields["age"]["active"] = True

                # Botones de nivel
                fy_lvl = fy1 + 55 + 35 + 28
                for lvl in range(1, MAX_LEVELS+1):
                    bx = field_x + (lvl-1)*(btn_w+8)
                    r  = pygame.Rect(bx, fy_lvl, btn_w, 38)
                    if r.collidepoint(mx,my):
                        self._intake_level = lvl

                # Botones de acción
                if self._intake_btn_cal.collidepoint(mx,my):
                    self.phase = "calibration"
                    self._cal_phase = "waiting"
                if self._intake_btn_start.collidepoint(mx,my):
                    self._launch_session()

    # ══════════════════════════════════════════════════════════
    #  CALIBRACIÓN
    # ══════════════════════════════════════════════════════════

    def _phase_calibration(self):
        self._update_camera()
        self.screen.fill(BG_COLOR)

        if self.cam_surface:
            self.screen.blit(self.cam_surface, (self.cam_x, self.cam_y))

        text_centered(self.screen, self.f_label, T["cal_title"],
                       (180,180,255), self.W//2, 40)

        if self._cal_phase == "waiting":
            text_centered(self.screen, self.f_small, T["cal_inst"],
                           (200,200,200), self.W//2, self.H-80)
            hint = self.f_tiny.render("Clic / ENTER para comenzar calibración",
                                       True, (120,200,120))
            self.screen.blit(hint, hint.get_rect(center=(self.W//2, self.H-50)))

        elif self._cal_phase == "recording":
            elapsed = time.perf_counter() - self._cal_start
            remain  = max(0, self._cal_duration - elapsed)
            # Barra de progreso
            prog = min(elapsed / self._cal_duration, 1.0)
            bar_w = int(self.W * 0.6 * prog)
            pygame.draw.rect(self.screen, (40,40,70),
                             (self.W//2-self.W//5*3//2, self.H-55,
                              int(self.W*0.6), 20), border_radius=10)
            pygame.draw.rect(self.screen, (80,200,120),
                             (self.W//2-self.W//5*3//2, self.H-55,
                              bar_w, 20), border_radius=10)
            text_centered(self.screen, self.f_small,
                           f"{T['cal_counting']}  {remain:.1f}s",
                           (200,240,200), self.W//2, self.H-25)

            # Procesar frame para calibración
            ret, raw = self.tracker._cap.read()
            if ret:
                frame_out, fx, fy = self.tracker.update_calibration(raw)

            if elapsed >= self._cal_duration:
                ok = self.tracker.finalize_calibration()
                self._cal_phase = "done" if ok else "fail"

        elif self._cal_phase == "done":
            text_centered(self.screen, self.f_label, T["cal_done"],
                           (80,220,100), self.W//2, self.H-60)
            hint = self.f_tiny.render("ENTER o clic para volver", True,(160,200,160))
            self.screen.blit(hint, hint.get_rect(center=(self.W//2, self.H-30)))

        elif self._cal_phase == "fail":
            text_centered(self.screen, self.f_label, T["cal_fail"],
                           (220,100,80), self.W//2, self.H-60)
            hint = self.f_tiny.render("ENTER o clic para reintentar",True,(200,160,160))
            self.screen.blit(hint, hint.get_rect(center=(self.W//2, self.H-30)))

        for event in pygame.event.get():
            if event.type == pygame.QUIT: self._quit()
            if event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                key = getattr(event, "key", None)
                if key == pygame.K_q: self._quit()
                if self._cal_phase == "waiting":
                    self.tracker.start_calibration()
                    self._cal_start = time.perf_counter()
                    self._cal_phase = "recording"
                elif self._cal_phase in ("done","fail"):
                    if self._cal_phase == "fail":
                        self._cal_phase = "waiting"
                    else:
                        self.phase = "intake"

    # ══════════════════════════════════════════════════════════
    #  LANZAR SESIÓN
    # ══════════════════════════════════════════════════════════

    def _launch_session(self):
        self.patient_id  = self._intake_fields["id"]["value"].strip() or "PAC001"
        try:
            self.patient_age = int(self._intake_fields["age"]["value"])
        except Exception:
            self.patient_age = 25
        self.age_group   = get_age_group(self.patient_age)
        self.start_level = self._intake_level
        self.recorder    = DataRecorder(patient_id=self.patient_id,
                                         age_group=self.age_group)
        self.level_stats = {}
        self._start_level(self.start_level)

    # ══════════════════════════════════════════════════════════
    #  ZONAS DE ESQUINA
    # ══════════════════════════════════════════════════════════

    def _compute_corner_rects(self, size_frac):
        sz  = int(self.H * size_frac)
        pad = int(self.H * 0.03)
        return {
            "top_left":     pygame.Rect(pad,           pad,           sz, sz),
            "top_right":    pygame.Rect(self.W-pad-sz, pad,           sz, sz),
            "bottom_left":  pygame.Rect(pad,           self.H-pad-sz, sz, sz),
            "bottom_right": pygame.Rect(self.W-pad-sz, self.H-pad-sz, sz, sz),
        }

    def _new_trial(self):
        lvl_cfg = get_level_config(self.age_group, self.current_level)
        names   = COLOR_NAMES.copy()

        if lvl_cfg["incongruent"]:
            self.word       = random.choice(names)
            rest            = [n for n in names if n != self.word]
            self.word_color = random.choice(rest)
        else:
            self.word       = random.choice(names)
            self.word_color = self.word

        self.word_color_rgb = COLOR_DICT[self.word_color]
        self.correct_answer = self.word_color

        shuffled = names.copy()
        random.shuffle(shuffled)
        self.corner_map = {pos: col for pos, col in zip(CORNERS, shuffled)}

        corner_rects  = self._compute_corner_rects(lvl_cfg["target_size"])
        self.zone_rects = {self.corner_map[pos]: corner_rects[pos]
                           for pos in CORNERS}

        self.stimulus_shown = False
        self.trial_start    = 0.0
        self.decision_onset = None
        self._pause_start   = None
        self.tracker.start_trial()

    # ══════════════════════════════════════════════════════════
    #  RENDER ZONAS
    # ══════════════════════════════════════════════════════════

    def _draw_zones(self, dwell_zone, dwell_progress):
        lvl_cfg      = get_level_config(self.age_group, self.current_level)
        corner_rects = self._compute_corner_rects(lvl_cfg["target_size"])

        for pos, color_name in self.corner_map.items():
            rect      = corner_rects[pos]
            color_rgb = COLOR_DICT[color_name]
            is_hover  = (self.finger_px is not None and
                         rect.collidepoint(self.finger_px, self.finger_py))

            draw_rrect(self.screen, rect, color_rgb,
                       radius=22, alpha=185 if is_hover else 130)
            pygame.draw.rect(self.screen,
                             (255,255,255) if is_hover else (80,80,110),
                             rect, 3 if is_hover else 1, border_radius=22)

            # Dwell ring
            if is_hover and dwell_progress > 0:
                cx, cy = rect.centerx, rect.centery
                r      = rect.width // 2 + 10
                arc_r  = pygame.Rect(cx-r, cy-r, r*2, r*2)
                pygame.draw.arc(self.screen, (255,255,255), arc_r,
                                math.radians(-90),
                                math.radians(-90 + 360*dwell_progress), 4)

            lbl = self.f_label.render(color_name, True, (255,255,255))
            self.screen.blit(lbl, lbl.get_rect(center=rect.center))

    # ══════════════════════════════════════════════════════════
    #  RENDER FEED CÁMARA CENTRAL
    # ══════════════════════════════════════════════════════════

    def _draw_cam_feed(self):
        # Marco
        frame_rect = pygame.Rect(self.cam_x-3, self.cam_y-3,
                                  self.cam_w+6, self.cam_h+6)
        pygame.draw.rect(self.screen, (50,50,80), frame_rect,
                         3, border_radius=6)

        if self.cam_surface:
            self.screen.blit(self.cam_surface, (self.cam_x, self.cam_y))
        else:
            # Placeholder si la cámara falla
            draw_rrect(self.screen,
                       (self.cam_x, self.cam_y, self.cam_w, self.cam_h),
                       (20,20,35), radius=4, alpha=200)
            msg = self.f_small.render("Sin señal de cámara", True, (120,80,80))
            self.screen.blit(msg, msg.get_rect(
                center=(self.cam_x+self.cam_w//2, self.cam_y+self.cam_h//2)))

    # ══════════════════════════════════════════════════════════
    #  ESTÍMULO CENTRAL (sobre el feed)
    # ══════════════════════════════════════════════════════════

    def _draw_stimulus(self):
        cx = self.W // 2
        cy = self.cam_y + self.cam_h // 2

        # Fondo semitransparente detrás de la palabra
        txt_surf = self.f_word.render(self.word, True, self.word_color_rgb)
        tw, th   = txt_surf.get_size()
        halo     = pygame.Surface((tw+50, th+26), pygame.SRCALPHA)
        halo.fill((0, 0, 0, 150))
        self.screen.blit(halo, (cx - tw//2 - 25, cy - th//2 - 13))
        self.screen.blit(txt_surf, txt_surf.get_rect(center=(cx, cy)))

    # ══════════════════════════════════════════════════════════
    #  CURSOR DE DEDO
    # ══════════════════════════════════════════════════════════

    def _draw_finger_cursor(self):
        if self.finger_px is None:
            return
        pygame.draw.circle(self.screen, (255,255,255),
                           (self.finger_px, self.finger_py), 9)
        pygame.draw.circle(self.screen, (255,220,60),
                           (self.finger_px, self.finger_py), 15, 2)

    # ══════════════════════════════════════════════════════════
    #  HUD
    # ══════════════════════════════════════════════════════════

    def _draw_hud(self):
        lvl_cfg  = get_level_config(self.age_group, self.current_level)
        lvl_name = LEVEL_NAMES[LANG][self.current_level]
        ag_lbl   = AGE_GROUPS[self.age_group]["label"][LANG]

        top = self.f_small.render(
            f"{T['level_lbl']} {self.current_level} — {lvl_name}  |  {ag_lbl}",
            True, (160,160,210))
        self.screen.blit(top, (10, 8))

        total = get_level_config(self.age_group, self.current_level)["trials"]
        tr_t  = self.f_tiny.render(
            f"{self.trial_index}/{total}", True, (120,120,160))
        self.screen.blit(tr_t, (10, 8+top.get_height()+2))

        pat = self.f_tiny.render(
            f"{T['patient']}: {self.patient_id}", True, (100,100,140))
        self.screen.blit(pat, (self.W - pat.get_width() - 10, 8))

        inst = self.f_tiny.render(T["instructions"], True, (150,150,190))
        self.screen.blit(inst, inst.get_rect(centerx=self.W//2, top=8))

        # Badge congruente / incongruente
        badge_txt = (T["congr_badge"] if not lvl_cfg["incongruent"]
                     else T["incongr_badge"])
        badge_col = (50,180,80) if not lvl_cfg["incongruent"] else (200,80,80)
        bsurf = self.f_tiny.render(badge_txt, True, badge_col)
        self.screen.blit(bsurf, bsurf.get_rect(
            centerx=self.W//2, top=inst.get_height()+14))

        # Sin mano detectada
        if self.finger_px is None and self.stimulus_shown:
            warn = self.f_small.render(T["no_hand"], True, (220,160,50))
            self.screen.blit(warn, warn.get_rect(
                center=(self.W//2, self.cam_y + self.cam_h + 18)))

        # Stats
        stats = self.level_stats.get(self.current_level,{"correct":0,"total":0})
        if stats["total"] > 0:
            acc = stats["correct"] / stats["total"] * 100
            sc  = self.f_tiny.render(
                f"{T['score']}: {acc:.0f}%", True,
                (80,220,100) if acc >= 80 else (220,140,60))
            self.screen.blit(sc, sc.get_rect(
                centerx=self.W//2,
                bottom=self.H - TIMER_BAR_HEIGHT - 6))

    # ══════════════════════════════════════════════════════════
    #  BARRA DE TIEMPO
    # ══════════════════════════════════════════════════════════

    def _draw_timer_bar(self, elapsed, time_limit):
        ratio = max(0, 1 - elapsed / time_limit)
        bw    = int(self.W * ratio)
        col   = lerp_col((220,50,50), (50,200,100), ratio)
        pygame.draw.rect(self.screen, (30,30,50),
                         (0, self.H-TIMER_BAR_HEIGHT, self.W, TIMER_BAR_HEIGHT))
        if bw > 0:
            pygame.draw.rect(self.screen, col,
                             (0, self.H-TIMER_BAR_HEIGHT, bw, TIMER_BAR_HEIGHT))
        ts = self.f_tiny.render(f"{max(0, time_limit-elapsed):.1f}s",
                                 True, (200,200,200))
        self.screen.blit(ts, (self.W-ts.get_width()-8,
                               self.H-TIMER_BAR_HEIGHT+2))

    # ══════════════════════════════════════════════════════════
    #  PARTÍCULAS
    # ══════════════════════════════════════════════════════════

    def _spawn_particles(self, x, y, color):
        for _ in range(20):
            a = random.uniform(0, 2*math.pi)
            s = random.uniform(2, 9)
            self.particles.append({
                "x":x,"y":y,"vx":math.cos(a)*s,"vy":math.sin(a)*s,
                "life":1.0,"color":color,"r":random.randint(3,7)})

    def _update_draw_particles(self):
        for p in self.particles:
            p["x"] += p["vx"]; p["y"] += p["vy"]
            p["vy"] += 0.2; p["life"] -= 0.04
        self.particles = [p for p in self.particles if p["life"] > 0]
        for p in self.particles:
            s = pygame.Surface((p["r"]*2,p["r"]*2), pygame.SRCALPHA)
            pygame.draw.circle(s,(*p["color"],int(p["life"]*255)),
                               (p["r"],p["r"]),p["r"])
            self.screen.blit(s,(int(p["x"])-p["r"],int(p["y"])-p["r"]))

    # ══════════════════════════════════════════════════════════
    #  FASE: TRIAL
    # ══════════════════════════════════════════════════════════

    def _phase_trial(self):
        lvl_cfg = get_level_config(self.age_group, self.current_level)
        elapsed = (time.perf_counter() - self.trial_start
                   if self.stimulus_shown else 0)

        self.screen.fill(BG_COLOR)
        self._update_draw_particles()
        self._draw_cam_feed()

        if self.stimulus_shown:
            dwell_name, dwell_prog = self.tracker.check_dwell_px(
                self.finger_px, self.finger_py, self.zone_rects)

            self._draw_zones(dwell_name, dwell_prog)
            self._draw_stimulus()
            self._draw_timer_bar(elapsed, lvl_cfg["time_limit"])
            self._draw_hud()
            self._draw_finger_cursor()

            # Decision onset
            if self.decision_onset is None and self.finger_px is not None:
                self.decision_onset = (time.perf_counter()-self.trial_start)*1000

            if elapsed >= lvl_cfg["time_limit"]:
                self._end_trial(None, timed_out=True)
                return
            if dwell_name:
                self._end_trial(dwell_name, timed_out=False)
                return
        else:
            # Cruz de fijación
            cross = self.f_word.render("+", True, (80,80,110))
            self.screen.blit(cross, cross.get_rect(
                center=(self.W//2, self.cam_y+self.cam_h//2)))
            self._draw_hud()
            if self._pause_start is None:
                self._pause_start = time.perf_counter()
            if time.perf_counter() - self._pause_start > 0.5:
                self.stimulus_shown = True
                self.trial_start    = time.perf_counter()

        for event in pygame.event.get():
            if event.type == pygame.QUIT: self._quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:    self._quit()
                if event.key == pygame.K_ESCAPE: self.phase = "intake"

    # ══════════════════════════════════════════════════════════
    #  FIN DE ENSAYO
    # ══════════════════════════════════════════════════════════

    def _end_trial(self, response, timed_out):
        lvl_cfg = get_level_config(self.age_group, self.current_level)
        rt_ms   = (time.perf_counter() - self.trial_start) * 1000

        motor = self.tracker.end_trial()
        correct = self.recorder.record_trial(
            level=self.current_level, word=self.word,
            word_color=self.word_color, word_color_rgb=self.word_color_rgb,
            correct_answer=self.correct_answer,
            congruent=not lvl_cfg["incongruent"],
            response=response, rt_ms=rt_ms,
            decision_onset_ms=self.decision_onset or 0,
            timed_out=timed_out, motor_metrics=motor,
            time_limit_s=lvl_cfg["time_limit"])

        if self.current_level not in self.level_stats:
            self.level_stats[self.current_level] = {"correct":0,"total":0}
        self.level_stats[self.current_level]["total"]  += 1
        if correct:
            self.level_stats[self.current_level]["correct"] += 1

        if timed_out:
            self.feedback_text  = T["timeout"]
            self.feedback_color = (255,200,50)
        elif correct:
            self.feedback_text  = T["correct"]
            self.feedback_color = (80,220,100)
            if self.finger_px:
                self._spawn_particles(self.finger_px,self.finger_py,(80,220,100))
        else:
            self.feedback_text  = T["wrong"]
            self.feedback_color = (220,80,80)

        self.last_rt_ms     = rt_ms
        self.feedback_until = time.perf_counter() + 0.85
        self.phase          = "feedback"

    # ══════════════════════════════════════════════════════════
    #  FASE: FEEDBACK
    # ══════════════════════════════════════════════════════════

    def _phase_feedback(self):
        self.screen.fill(BG_COLOR)
        self._update_draw_particles()
        self._draw_cam_feed()

        fb  = self.f_word.render(self.feedback_text, True, self.feedback_color)
        rt  = self.f_small.render(f"RT: {self.last_rt_ms:.0f} ms", True,(200,200,200))
        self.screen.blit(fb, fb.get_rect(center=(self.W//2, self.H//2-30)))
        self.screen.blit(rt, rt.get_rect(center=(self.W//2, self.H//2+30)))

        for event in pygame.event.get():
            if event.type == pygame.QUIT: self._quit()

        if time.perf_counter() >= self.feedback_until:
            self.trial_index += 1
            lvl_cfg = get_level_config(self.age_group, self.current_level)
            if self.trial_index >= lvl_cfg["trials"]:
                if self.current_level < MAX_LEVELS:
                    self.phase = "level_results"
                else:
                    self.phase = "end"
            else:
                self._new_trial()
                self.phase = "trial"

    # ══════════════════════════════════════════════════════════
    #  FASE: RESULTADOS DE NIVEL
    # ══════════════════════════════════════════════════════════

    def _phase_level_results(self):
        self.screen.fill(BG_COLOR)
        stats = self.level_stats.get(self.current_level,{"correct":0,"total":1})
        acc   = stats["correct"] / max(stats["total"],1) * 100

        text_centered(self.screen, self.f_word,
                       f"{T['level_lbl']} {self.current_level} — "
                       f"{LEVEL_NAMES[LANG][self.current_level]}",
                       (180,180,255), self.W//2, self.H//2-90, shadow=True)
        text_centered(self.screen, self.f_label,
                       f"{T['score']}: {acc:.1f}%",
                       (80,220,100) if acc>=80 else (220,120,80),
                       self.W//2, self.H//2)

        # Norma
        grp     = AGE_GROUPS[self.age_group]
        norm_acc= grp.get("norm_accuracy", 0)
        diff    = acc - norm_acc
        norm_t  = self.f_small.render(
            f"Norma grupo edad: {norm_acc}%   Diferencia: {diff:+.1f}%",
            True, (160,200,160))
        self.screen.blit(norm_t, norm_t.get_rect(center=(self.W//2, self.H//2+50)))

        cont = self.f_small.render(T["next_level"], True, (140,200,140))
        self.screen.blit(cont, cont.get_rect(center=(self.W//2, self.H//2+100)))

        for event in pygame.event.get():
            if event.type == pygame.QUIT: self._quit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self._start_level(self.current_level + 1)

    def _start_level(self, lvl):
        self.current_level = lvl
        self.trial_index   = 0
        if lvl not in self.level_stats:
            self.level_stats[lvl] = {"correct":0,"total":0}
        self._new_trial()
        self.phase = "trial"

    # ══════════════════════════════════════════════════════════
    #  FASE: FIN
    # ══════════════════════════════════════════════════════════

    def _phase_end(self):
        self.screen.fill(BG_COLOR)
        msg = self.f_label.render(T["finished"], True, (140,200,140))
        self.screen.blit(msg, msg.get_rect(center=(self.W//2,self.H//2)))
        pygame.display.flip()

        summary = self.recorder.get_summary()
        trials  = self.recorder.get_all_trials()
        pdf     = generate_full_report(summary, trials,
                                        patient_id=self.patient_id,
                                        age_group=self.age_group)
        self.screen.fill(BG_COLOR)
        text_centered(self.screen, self.f_label, "✓ Reporte generado",
                       (80,220,100), self.W//2, self.H//2-20)
        p_lbl = self.f_tiny.render(pdf, True, (140,140,180))
        self.screen.blit(p_lbl, p_lbl.get_rect(center=(self.W//2, self.H//2+30)))
        q_lbl = self.f_small.render("Q para salir", True, (180,180,180))
        self.screen.blit(q_lbl, q_lbl.get_rect(center=(self.W//2, self.H//2+80)))
        pygame.display.flip()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: self._quit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_q:
                    self._quit()
            self.clock.tick(30)

    # ══════════════════════════════════════════════════════════
    #  LOOP PRINCIPAL
    # ══════════════════════════════════════════════════════════

    def run(self):
        while True:
            if self.phase not in ("intake", "calibration"):
                self._update_camera()

            if   self.phase == "intake":         self._phase_intake()
            elif self.phase == "calibration":    self._phase_calibration()
            elif self.phase == "trial":          self._phase_trial()
            elif self.phase == "feedback":       self._phase_feedback()
            elif self.phase == "level_results":  self._phase_level_results()
            elif self.phase == "end":            self._phase_end()

            pygame.display.flip()
            self.clock.tick(60)

    def _quit(self):
        try: self.tracker.release()
        except Exception: pass
        cv2.destroyAllWindows()
        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    StroopGame().run()
