"""
report_generator.py  v2
────────────────────────
Igual que v1 + gráfica de comparación normativa por grupo de edad.
"""

import os
from datetime import datetime
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                 Table, TableStyle, Image as RLImage,
                                 HRFlowable)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from config import REPORTS_DIR, PATIENT_ID, LANGUAGE, AGE_GROUPS, LEVEL_NAMES

PALETTE = {1:"#4CAF50",2:"#2196F3",3:"#FF9800",4:"#E91E63",5:"#9C27B0"}
DARK_BG  = "#0d0d1a"
DARK_AX  = "#1a1a2e"


def _lname(lvl):
    return LEVEL_NAMES.get(LANGUAGE, LEVEL_NAMES["es"]).get(lvl, str(lvl))


def _dark_fig(figsize=(9, 4)):
    fig, ax = plt.subplots(figsize=figsize)
    fig.patch.set_facecolor(DARK_BG)
    ax.set_facecolor(DARK_AX)
    ax.tick_params(colors="white")
    for sp in ax.spines.values():
        sp.set_edgecolor("#333")
    return fig, ax


def _dark_fig2(figsize=(12, 4)):
    fig, axes = plt.subplots(1, 2, figsize=figsize)
    fig.patch.set_facecolor(DARK_BG)
    for ax in axes:
        ax.set_facecolor(DARK_AX)
        ax.tick_params(colors="white")
        for sp in ax.spines.values():
            sp.set_edgecolor("#333")
    return fig, axes


def generate_charts(summary, trials, age_group, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    paths  = {}
    levels = sorted(summary.keys())
    cols   = [PALETTE.get(l, "#888") for l in levels]
    names  = [f"Nv.{l}\n{_lname(l)}" for l in levels]

    # 1 ── RT por nivel
    fig, ax = _dark_fig()
    means = [summary[l]["mean_rt_ms"] for l in levels]
    bars  = ax.bar(names, means, color=cols, edgecolor="white", linewidth=0.8)
    ax.set_ylabel("RT promedio (ms)", color="white")
    ax.set_title("Tiempo de Reacción por Nivel", color="white", fontweight="bold")
    ax.yaxis.label.set_color("white")
    for bar, val in zip(bars, means):
        ax.text(bar.get_x()+bar.get_width()/2, val+12,
                f"{val:.0f}", ha="center", color="white", fontsize=8)
    p = os.path.join(out_dir, "chart_rt.png")
    fig.tight_layout(); fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    paths["rt"] = p

    # 2 ── Precisión
    fig, ax = _dark_fig()
    accs = [summary[l]["accuracy_pct"] for l in levels]
    bars = ax.bar(names, accs, color=cols, edgecolor="white", linewidth=0.8)
    ax.set_ylim(0, 115)
    ax.axhline(80, color="#FF5722", ls="--", alpha=0.7, label="Umbral 80%")
    ax.legend(facecolor=DARK_AX, labelcolor="white")
    ax.set_ylabel("Precisión (%)", color="white")
    ax.set_title("Precisión por Nivel", color="white", fontweight="bold")
    ax.yaxis.label.set_color("white")
    for bar, val in zip(bars, accs):
        ax.text(bar.get_x()+bar.get_width()/2, val+1,
                f"{val:.1f}%", ha="center", color="white", fontsize=8)
    p = os.path.join(out_dir, "chart_accuracy.png")
    fig.tight_layout(); fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    paths["accuracy"] = p

    # 3 ── Curva de aprendizaje
    fig, ax = _dark_fig((11, 4))
    for lvl in levels:
        pts = [(t["trial_number"], t["rt_ms"])
               for t in trials if t["level"] == lvl and not t["timed_out"]]
        if pts:
            ns, rs = zip(*pts)
            ax.scatter(ns, rs, color=PALETTE.get(lvl,"#888"), s=35, alpha=0.75,
                       label=f"Nv.{lvl}")
            wnd = 3
            if len(rs) >= wnd:
                ma = [sum(rs[max(0,i-wnd):i+1])/len(rs[max(0,i-wnd):i+1])
                      for i in range(len(rs))]
                ax.plot(ns, ma, color=PALETTE.get(lvl,"#888"), lw=1.5)
    ax.set_xlabel("Ensayo", color="white")
    ax.set_ylabel("RT (ms)", color="white")
    ax.set_title("Evolución del RT", color="white", fontweight="bold")
    ax.xaxis.label.set_color("white")
    ax.legend(facecolor=DARK_AX, labelcolor="white", fontsize=8)
    p = os.path.join(out_dir, "chart_learning.png")
    fig.tight_layout(); fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    paths["learning"] = p

    # 4 ── Métricas motoras
    if len(levels) >= 2:
        fig, axes = _dark_fig2()
        for ax, key, lbl in zip(axes,
                                 ["mean_tremor","mean_corrections"],
                                 ["Índice de Temblor","Correcciones Motoras"]):
            vals = [summary[l].get(key, 0) for l in levels]
            ax.bar(names, vals, color=cols, edgecolor="white", linewidth=0.8)
            ax.set_title(lbl, color="white", fontweight="bold")
            ax.yaxis.label.set_color("white")
        p = os.path.join(out_dir, "chart_motor.png")
        fig.tight_layout(); fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
        paths["motor"] = p

    # 5 ── Comparación normativa (nuevo en v2)
    grp = AGE_GROUPS.get(age_group, {})
    if grp and len(levels) >= 2:
        fig, ax = _dark_fig((9, 4.5))
        # RT paciente vs norma
        rt_cong   = summary.get(1, {}).get("mean_rt_ms", 0)
        rt_incong = max((summary.get(l, {}).get("mean_rt_ms", 0)
                         for l in levels if l > 1), default=0)
        norm_cong   = grp.get("norm_rt_congruent", 0)
        norm_incong = grp.get("norm_rt_incongruent", 0)

        categories = ["RT Congruente", "RT Incongruente"]
        patient_v  = [rt_cong, rt_incong]
        norm_v     = [norm_cong, norm_incong]
        x          = range(len(categories))
        w          = 0.35

        ax.bar([i - w/2 for i in x], patient_v, w,
               color="#42A5F5", label="Paciente", edgecolor="white", linewidth=0.8)
        ax.bar([i + w/2 for i in x], norm_v, w,
               color="#78909C", label=f"Norma ({grp['label'][LANGUAGE]})",
               edgecolor="white", linewidth=0.8)
        ax.set_xticks(list(x)); ax.set_xticklabels(categories, color="white")
        ax.set_ylabel("ms", color="white")
        ax.yaxis.label.set_color("white")
        ax.set_title("Paciente vs. Norma del Grupo de Edad", color="white", fontweight="bold")
        ax.legend(facecolor=DARK_AX, labelcolor="white")

        p = os.path.join(out_dir, "chart_norm.png")
        fig.tight_layout(); fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
        paths["norm"] = p

    return paths


def generate_pdf(summary, trials, patient_id, age_group, chart_paths, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    date_str = datetime.now().strftime("%Y-%m-%d_%H-%M")
    fname    = os.path.join(out_dir, f"reporte_{patient_id}_{date_str}.pdf")

    doc    = SimpleDocTemplate(fname, pagesize=A4,
                                leftMargin=2*cm, rightMargin=2*cm,
                                topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()

    title_s = ParagraphStyle("t",  fontSize=20, fontName="Helvetica-Bold",
                              textColor=colors.HexColor("#1a237e"),
                              alignment=TA_CENTER, spaceAfter=6)
    sub_s   = ParagraphStyle("s",  fontSize=11,
                              textColor=colors.HexColor("#455a64"),
                              alignment=TA_CENTER, spaceAfter=12)
    h2_s    = ParagraphStyle("h2", fontSize=13, fontName="Helvetica-Bold",
                              textColor=colors.HexColor("#1a237e"), spaceBefore=14)
    body_s  = ParagraphStyle("b",  fontSize=10, leading=14)

    story = []
    grp   = AGE_GROUPS.get(age_group, {})

    story.append(Paragraph("Stroop Cognitivo Adaptativo v2", title_s))
    story.append(Paragraph("Reporte de Evaluación Neuropsicológica", sub_s))
    story.append(HRFlowable(width="100%", thickness=2,
                             color=colors.HexColor("#1a237e")))
    story.append(Spacer(1, 0.3*cm))

    total_t  = len(trials)
    total_ok = sum(1 for t in trials if t["correct"])
    total_to = sum(1 for t in trials if t["timed_out"])
    all_rts  = [t["rt_ms"] for t in trials if not t["timed_out"]]
    mean_rt  = sum(all_rts)/len(all_rts) if all_rts else 0

    info = [
        ["Paciente",    patient_id,
         "Fecha",       datetime.now().strftime("%d/%m/%Y %H:%M")],
        ["Grupo edad",  grp.get("label", {}).get(LANGUAGE, age_group),
         "Ensayos",     str(total_t)],
        ["Correctos",   f"{total_ok} ({total_ok/max(total_t,1)*100:.1f}%)",
         "Timeouts",    str(total_to)],
        ["RT global",   f"{mean_rt:.0f} ms",
         "Norma RT inc",f"{grp.get('norm_rt_incongruent','—')} ms"],
    ]
    tbl = Table(info, colWidths=[3.2*cm, 4.8*cm, 3.2*cm, 4.8*cm])
    tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(0,-1), colors.HexColor("#e8eaf6")),
        ("BACKGROUND",(2,0),(2,-1), colors.HexColor("#e8eaf6")),
        ("FONTNAME",  (0,0),(-1,-1),"Helvetica"),
        ("FONTSIZE",  (0,0),(-1,-1), 9),
        ("GRID",      (0,0),(-1,-1), 0.5, colors.HexColor("#c5cae9")),
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[colors.white,colors.HexColor("#f5f5f5")]),
        ("TOPPADDING",(0,0),(-1,-1), 5),
        ("BOTTOMPADDING",(0,0),(-1,-1), 5),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 0.4*cm))

    # Tabla de métricas Stroop clásicas
    story.append(Paragraph("Métricas Neuropsicológicas Stroop", h2_s))
    story.append(Spacer(1, 0.2*cm))

    hdr = ["Nivel","Ensayos","Precisión","RT Prom","σ RT",
           "Interferencia","Temblor","Correcciones"]
    rows = [hdr]
    for lvl in sorted(summary.keys()):
        s = summary[lvl]
        rows.append([
            f"Nv.{lvl} {_lname(lvl)}",
            str(s["total"]),
            f"{s['accuracy_pct']}%",
            f"{s['mean_rt_ms']} ms",
            f"{s.get('std_rt_ms',0)} ms",
            f"{s['interference_ms']:+.0f} ms",
            f"{s['mean_tremor']:.4f}",
            f"{s['mean_corrections']:.2f}",
        ])
    t2 = Table(rows, colWidths=[3.0*cm,1.5*cm,1.8*cm,2.0*cm,
                                  1.8*cm,2.3*cm,1.8*cm,2.0*cm])
    t2.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0), colors.HexColor("#1a237e")),
        ("TEXTCOLOR", (0,0),(-1,0), colors.white),
        ("FONTNAME",  (0,0),(-1,0), "Helvetica-Bold"),
        ("FONTSIZE",  (0,0),(-1,-1), 8),
        ("ALIGN",     (0,0),(-1,-1), "CENTER"),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),
         [colors.white, colors.HexColor("#f3f4ff")]),
        ("GRID",      (0,0),(-1,-1), 0.5, colors.HexColor("#c5cae9")),
        ("TOPPADDING",(0,0),(-1,-1), 4),
        ("BOTTOMPADDING",(0,0),(-1,-1), 4),
    ]))
    story.append(t2)
    story.append(Spacer(1, 0.4*cm))

    # Gráficas
    story.append(Paragraph("Análisis Visual", h2_s))
    for key, lbl in [("norm","Comparación con Norma del Grupo de Edad"),
                     ("rt","Tiempo de Reacción por Nivel"),
                     ("accuracy","Precisión por Nivel"),
                     ("learning","Evolución del RT"),
                     ("motor","Métricas Motoras")]:
        p = chart_paths.get(key)
        if p and os.path.exists(p):
            story.append(Paragraph(lbl, body_s))
            story.append(RLImage(p, width=15*cm, height=6.5*cm))
            story.append(Spacer(1, 0.3*cm))

    # Observaciones
    story.append(HRFlowable(width="100%", thickness=1,
                             color=colors.HexColor("#c5cae9")))
    story.append(Paragraph("Observaciones Automáticas", h2_s))
    story.append(Spacer(1, 0.2*cm))

    obs = []
    norm_int = grp.get("norm_interference", 0)
    lvls     = sorted(summary.keys())

    if len(lvls) >= 2:
        rt1   = summary[lvls[0]]["mean_rt_ms"]
        rtL   = summary[lvls[-1]]["mean_rt_ms"]
        obs.append(f"• RT aumentó {(rtL-rt1):.0f} ms del nivel 1 al nivel {lvls[-1]} "
                   f"({rt1:.0f} → {rtL:.0f} ms).")

    for lvl in lvls:
        s = summary[lvl]
        interf = s["interference_ms"]
        if lvl > 1 and abs(interf) > 0:
            flag = "elevado" if interf > norm_int * 1.3 else "normal"
            obs.append(f"• Nivel {lvl} — Índice de interferencia: {interf:+.0f} ms "
                       f"(norma: {norm_int:+.0f} ms) → {flag}.")
        if s["accuracy_pct"] < 60:
            obs.append(f"• Nivel {lvl}: precisión baja ({s['accuracy_pct']}%). "
                       "Posible dificultad de control inhibitorio.")
        if s["mean_tremor"] > 0.05:
            obs.append(f"• Nivel {lvl}: temblor elevado ({s['mean_tremor']:.4f}). "
                       "Revisar función motora fina.")
        if s["timeouts"] > s["total"] * 0.3:
            obs.append(f"• Nivel {lvl}: {s['timeouts']} timeouts. "
                       "Tiempo límite podría requerir ajuste para este paciente.")

    if not obs:
        obs.append("• Sin observaciones destacadas.")
    obs.append("\n⚠️ Herramienta de apoyo diagnóstico. "
               "Interpretación clínica a cargo de profesional certificado.")

    for line in obs:
        story.append(Paragraph(line, body_s))
        story.append(Spacer(1, 0.1*cm))

    doc.build(story)
    return fname


def generate_full_report(summary, trials, patient_id=PATIENT_ID,
                          age_group="young_adult"):
    ts      = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(REPORTS_DIR, f"{patient_id}_{ts}")
    charts  = generate_charts(summary, trials, age_group, out_dir)
    pdf     = generate_pdf(summary, trials, patient_id, age_group, charts, out_dir)
    return pdf
